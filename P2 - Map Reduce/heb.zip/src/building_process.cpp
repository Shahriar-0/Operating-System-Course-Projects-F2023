#include "building_process.hpp"

Building::Building(Logger* log, std::string name, std::string path) {
    log_ = log;
    name_ = name;
    path_ = path;
    log_->info("start to work");
    createResources();
    financialConnectionSetup();
}

void Building::createResource(const std::string resource) {
    int pipeFds1[2], pipeFds2[2], pid;
    if (pipe(pipeFds1) == -1 || pipe(pipeFds2) == -1)
        throw new std::runtime_error("problem in creating pipe");

    pid = fork();
    if (pid == 0) {
        log_->info("creating resource " + resource);
        setupUnnamedPipes(pipeFds1, pipeFds2);
        execl(EXE_RESOURCE, EXE_RESOURCE, std::string(path_ + "/" + name_).c_str(), name_.c_str(),
              resource.c_str(), nullptr);
        throw new std::runtime_error("problem in executing resource " + resource);
    } else if (pid > 0) {
        close(pipeFds1[0]);
        close(pipeFds2[1]);
        resources_.push_back(new ChildUnit(resource, pipeFds1[1], pipeFds2[0], pid));
    } else
        throw new std::runtime_error("problem in forking resources");
}

void Building::createResources() {
    createResource(WATER);
    createResource(GAS);
    createResource(ELECTRICITY);
}

void Building::financialConnectionSetup() {
    log_->info("connecting to " + std::string(FINANCIAL_NAME));
    financialUnit_ = new CoworkerUnit(name_, DEFAULT_ID);
}

void Building::start() {
    while (true) {
        std::vector<std::string> args;
        std::string cmd = readfd(STDIN_FILENO, args);
        handleCmd(cmd, args);
    }
}

void Building::handleCmd(const std::string& cmd, const std::vector<std::string>& args) {
    if (cmd == MSG_CLOSE)
        closeProcess(false);
    else if (cmd == MSG_REPORT_FOR_MEAN)
        meanReport(args);
    else if (cmd == MSG_REPORT_FOR_TOTAL)
        totalReport(args);
    else if (cmd == MSG_REPORT_FOR_PEAK)
        maxReport(args);
    else if (cmd == MSG_REPORT_FOR_DIFFERENCE)
        diffReport(args);
    else if (cmd == MSG_REPORT_BILL)
        billReport(args);
    else
        log_->error("unknown command");
}

void Building::closeProcess(bool isError) {
    for (long unsigned int i = 0; i < resources_.size(); i++) resources_[i]->sendMessage(MSG_CLOSE);
    return;
}

void Building::meanReport(const std::vector<std::string>& args) {
    int index = findResource(args[0]);
    std::string monthNumber = args[1];
    log_->info("send mean report request to resource " + resources_[index]->getName());
    resources_[index]->sendMessage(MSG_REPORT_FOR_MEAN, {monthNumber});
    std::vector<std::string> resArgs;
    resources_[index]->receiveMessage(resArgs);
    writefd(STDOUT_FILENO, MSG_RESPONSE, resArgs);
}

void Building::totalReport(const std::vector<std::string>& args) {
    int index = findResource(args[0]);
    std::string monthNumber = args[1];
    log_->info("send total report request to resource " + resources_[index]->getName());
    resources_[index]->sendMessage(MSG_REPORT_FOR_TOTAL, {monthNumber});
    std::vector<std::string> resArgs;
    resources_[index]->receiveMessage(resArgs);
    writefd(STDOUT_FILENO, MSG_RESPONSE, resArgs);
}

void Building::maxReport(const std::vector<std::string>& args) {
    int index = findResource(args[0]);
    std::string monthNumber = args[1];
    log_->info("send max hours usage report request to resource " + resources_[index]->getName() +
               "");
    resources_[index]->sendMessage(MSG_REPORT_FOR_PEAK, {monthNumber});
    std::vector<std::string> resArgs;
    resources_[index]->receiveMessage(resArgs);
    writefd(STDOUT_FILENO, MSG_RESPONSE, resArgs);
}

void Building::diffReport(const std::vector<std::string>& args) {
    int index = findResource(args[0]);
    std::string monthNumber = args[1];
    log_->info("send difference report request to resource " + resources_[index]->getName());
    resources_[index]->sendMessage(MSG_REPORT_FOR_DIFFERENCE, {monthNumber});
    std::vector<std::string> resArgs;
    resources_[index]->receiveMessage(resArgs);
    writefd(STDOUT_FILENO, MSG_RESPONSE, resArgs);
}

void Building::billReport(const std::vector<std::string>& args) {
    std::string resourceType = args[0];
    int index = findResource(resourceType);
    std::string monthNumber = args[1];
    log_->info("getting bills config from " + std::string(FINANCIAL_NAME));
    std::vector<std::string> param;
    financialUnit_->receiveMessage(param);
    resources_[index]->sendMessage(MSG_REPORT_BILL, {monthNumber, resourceType, param[0]});
    std::vector<std::string> resArgs;
    resources_[index]->receiveMessage(resArgs);
    writefd(STDOUT_FILENO, MSG_RESPONSE, resArgs);
}

int Building::findResource(const std::string& name) {
    for (long unsigned int i = 0; i < resources_.size(); i++)
        if (resources_[i]->getName() == name) return i;

    return -1;
}
