#include "utils.hpp"

#include "consts.hpp"

std::vector<std::string> GetFilesOfDirectory(const char* path) {
    std::vector<std::string> names;

    DIR* dir = opendir(path);
    if (!dir) return names;
    struct dirent* entry = readdir(dir);
    while (entry != NULL) {
        if (entry->d_type == DT_DIR) names.push_back(entry->d_name);

        entry = readdir(dir);
    }
    closedir(dir);

    names.erase(std::remove(names.begin(), names.end(), "."), names.end());
    names.erase(std::remove(names.begin(), names.end(), ".."), names.end());

    return names;
}

std::vector<std::string> charArrayToVector(char** args, int start, int end) {
    std::vector<std::string> res;
    for (int i = start; i <= end; i++) res.push_back(args[i]);
    return res;
}

char** vectorToCharArray(const std::vector<std::string>& args) {
    char** generated = (char**)malloc((args.size() + 1) * sizeof(char*));

    for (long unsigned int i = 0; i < args.size(); i++) {
        generated[i] = (char*)malloc((args[i].size() + 1) * sizeof(char));
        std::copy(args[i].begin(), args[i].end(), generated[i]);
        generated[i][args[i].size()] = '\0';
    }
    generated[args.size()] = nullptr;

    return generated;
}

void setupUnnamedPipes(int* fds1, int* fds2) {
    close(fds2[0]);
    dup2(fds1[0], STDIN_FILENO);
    close(fds1[0]);
    close(fds1[1]);
    dup2(fds2[1], STDOUT_FILENO);
    close(fds2[1]);
}

void writefd(int fd, const std::string& cmd, const std::vector<std::string>& args) {
    std::string msg = encode(cmd, args);
    write(fd, (msg + '\0').c_str(), msg.size() + 1);
}

std::string readfd(int fd, std::vector<std::string>& args) {
    char buf[BUFSIZE];
    read(fd, buf, BUFSIZE);
    return decode(std::string(buf), args);
}

void trimLeft(std::string& str) {
    str.erase(str.begin(), std::find_if(str.begin(), str.end(),
                                        [](unsigned char ch) { return !std::isspace(ch); }));
}

void trimRight(std::string& str) {
    str.erase(
        std::find_if(str.rbegin(), str.rend(), [](unsigned char ch) { return !std::isspace(ch); })
            .base(),
        str.end());
}

void trim(std::string& str) {
    trimLeft(str);
    trimRight(str);
}

std::vector<std::string> split(const std::string& str, char delim) {
    std::istringstream sstr(str);
    std::string item;
    std::vector<std::string> result;
    while (std::getline(sstr, item, delim)) {
        result.push_back(std::move(item));
    }
    return result;
}

std::string encode(const std::string& cmd, const std::vector<std::string>& args) {
    std::string msg = cmd;
    for (const std::string& arg : args) msg += " " + arg;
    return msg;
}

std::string decode(const std::string& msg, std::vector<std::string>& args) {
    std::stringstream ss(msg);
    args.clear();
    std::string substr;
    while (getline(ss, substr, ' ')) args.push_back(substr);
    std::string cmd = args[0];
    args.erase(args.begin());
    return cmd;
}

std::vector<std::string> split(const std::string& str, const std::string& delim) {
    std::string::size_type startPos = 0;
    std::string::size_type endPos;

    std::vector<std::string> result;
    while ((endPos = str.find(delim, startPos)) != std::string::npos) {
        result.push_back(str.substr(startPos, endPos - startPos));
        startPos = endPos + delim.size();
    }
    result.push_back(str.substr(startPos));

    return result;
}

void emptyLog() {
    std::ofstream ofs;
    ofs.open(LOG_PATH, std::ofstream::out | std::ofstream::trunc);
    ofs.close();
}

ResourceUsage::ResourceUsage(std::string CSVPath) {
    CSVPath_ = CSVPath;
    loadCSV();
}

void ResourceUsage::loadCSV() {
    std::ifstream CSVfile(CSVPath_);
    std::string line;
    std::getline(CSVfile, line);
    while (std::getline(CSVfile, line)) {
        std::vector<std::string> tempParam = split(line, ",");
        trim(tempParam[0]);
        trim(tempParam[1]);
        trim(tempParam[2]);

        ResourceUsageRecord* newRecord = new ResourceUsageRecord;
        newRecord->year = tempParam[0];
        newRecord->month = atoi(tempParam[1].c_str());
        newRecord->day = atoi(tempParam[2].c_str());
        assignHours(newRecord, tempParam);

        records_.push_back(newRecord);
    }
}

std::string vectorToString(const std::vector<std::string>& args) {
    std::string res;
    for (const auto& arg : args) res += arg + " ";
    return res;
}

void ResourceUsage::assignHours(ResourceUsageRecord* newRecord,
                                std::vector<std::string>& tempParam) {
    for (long unsigned int i = 0; i < HOUR_COUNT; i++) {
        newRecord->hoursUsage[i] = atoi(tempParam[i + 3].c_str());
    }
}
int ResourceUsage::mean(int month) {
    int sum = 0;
    for (long unsigned int i = 0; i < records_.size(); i++)
        if (records_[i]->month == month)
            for (long unsigned int j = 0; j < HOUR_COUNT; j++) sum += records_[i]->hoursUsage[j];

    return sum / 30;
}

int ResourceUsage::difference(int month) {
    int m = mean(month) / HOUR_COUNT;
    std::vector<int> max = maxUsage(month);
    int totalMax = totalUsage(month, max[0]) / 30;
    return totalMax - m;
}

std::string prompt(std::string msg) {
    std::cout << MAGENTA << msg << RESET;
    std::string res;
    std::getline(std::cin, res);
    return res;
}

std::vector<int> ResourceUsage::maxUsage(int month) {
    int totalUsage[HOUR_COUNT];
    for (long unsigned int i = 0; i < HOUR_COUNT; i++) {
        totalUsage[i] = 0;
        for (long unsigned int j = 0; j < records_.size(); j++) {
            if (records_[j]->month == month) totalUsage[i] += records_[j]->hoursUsage[i];
        }
    }

    std::vector<int> maxUsagesIndex;
    int maxUsage = 0;
    for (long unsigned int i = 0; i < HOUR_COUNT; i++) {
        if (maxUsage < totalUsage[i]) {
            maxUsage = totalUsage[i];
            maxUsagesIndex.clear();
            maxUsagesIndex.push_back(i);
        } else if (maxUsage == totalUsage[i]) {
            maxUsagesIndex.push_back(i);
        }
    }

    return maxUsagesIndex;
}

int ResourceUsage::totalUsage(int month, int hour) {
    int sum = 0;
    for (long unsigned int i = 0; i < records_.size(); i++)
        if (records_[i]->month == month) sum += records_[i]->hoursUsage[hour];

    return sum;
}

int ResourceUsage::water(int month, int param) {
    int res = 0;
    std::vector<int> maxHours = maxUsage(month);

    for (const auto& record : records_) {
        if (record->month == month) {
            for (long unsigned int j = 0; j < HOUR_COUNT; j++) {
                bool isMax = std::find(maxHours.begin(), maxHours.end(), j) != maxHours.end();
                res += (isMax) ? record->hoursUsage[j] * 1.25 : record->hoursUsage[j];
            }
        }
    }

    return res * param;
}

int ResourceUsage::gas(int month, int param) {
    int res = 0;
    int totalUsage = mean(month) * 30;
    res = totalUsage * param;
    return res;
}

int ResourceUsage::electricity(int month, int param) {
    int res = 0;
    std::vector<int> maxHours = maxUsage(month);

    for (const auto& record : records_) {
        if (record->month == month) {
            for (long unsigned int j = 0; j < HOUR_COUNT; j++) {
                bool isMax = std::find(maxHours.begin(), maxHours.end(), j) != maxHours.end();
                int high = record->hoursUsage[j];
                res += isMax ? high * 1.25 : (high < mean(month) / HOUR_COUNT) ? high * 0.75 : high;
            }
        }
    }

    return res * param;
}

BillConfig::BillConfig(std::string CSVPath) {
    CSVPath_ = CSVPath;
    loadCSV();
}

void BillConfig::loadCSV() {
    std::ifstream CSVfile(CSVPath_);
    std::string line;
    std::getline(CSVfile, line);
    while (std::getline(CSVfile, line)) {
        std::stringstream ss(line);
        std::vector<std::string> tempParam;
        while (ss.good()) {
            std::string substr;
            std::getline(ss, substr, ',');
            tempParam.push_back(substr);
        }

        BillConfigRecord* newRecord = new BillConfigRecord;
        newRecord->year = tempParam[0];
        newRecord->month = atoi(tempParam[1].c_str());
        newRecord->water = atoi(tempParam[2].c_str());
        newRecord->gas = atoi(tempParam[3].c_str());
        newRecord->electricity = atoi(tempParam[4].c_str());

        records_.push_back(newRecord);
    }
}

std::vector<int> BillConfig::getParam(int month) {
    for (long unsigned int i = 0; i < records_.size(); i++)
        if (records_[i]->month == month)
            return {records_[i]->water, records_[i]->gas, records_[i]->electricity};

    throw new std::runtime_error("no record found");
}
