#include "company_process.hpp"

Company::Company(const char* buildingsPath, Logger* log) {
    log_ = log;
    log_->info("Company initialization started");

    try {
        std::vector<std::string> buildingNames = getBuildings(buildingsPath);
        createBuildings(buildingNames, buildingsPath);
        createFinancialUnit(buildingNames);
        emptyLog();

        log_->info("Company initialization completed successfully");
    } catch (const std::exception& e) {
        log_->error("Company initialization failed: " + std::string(e.what()));
        throw;
    }
}

std::vector<std::string> Company::getBuildings(const char* path) {
    std::vector<std::string> names = GetFilesOfDirectory(path);
    if (names.empty()) {
        log_->error("No buildings found in the directory");
        throw std::runtime_error("No buildings found in the directory");
    }
    log_->info("Found " + std::to_string(names.size()) + " buildings");
    return names;
}

void Company::createBuildings(const std::vector<std::string>& names, const char* buildingsPath) {
    for (const auto& name : names) {
        int pipeFds1[2], pipeFds2[2], pid;
        if (pipe(pipeFds1) == -1 || pipe(pipeFds2) == -1) {
            log_->error("Problem in creating pipe");
            throw std::runtime_error("Problem in creating pipe");
        }

        pid = fork();
        if (pid == 0) {
            log_->info("Creating building: " + name);
            setupUnnamedPipes(pipeFds1, pipeFds2);
            execl(EXE_BUILDING, EXE_BUILDING, buildingsPath, name.c_str(), nullptr);
            log_->error("Problem in executing building: " + name);
            throw std::runtime_error("Problem in executing building: " + name);
        } else if (pid > 0) {
            close(pipeFds1[0]);
            close(pipeFds2[1]);
            buildings_.push_back(new ChildUnit(name, pipeFds1[1], pipeFds2[0], pid));
        } else {
            log_->error("Problem in forking buildings");
            throw std::runtime_error("Problem in forking buildings");
        }
    }
}

void Company::createFinancialUnit(const std::vector<std::string>& buildingNames) {
    log_->info("Creating financial unit: " + std::string(FINANCIAL_NAME));

    int pipeFds1[2], pipeFds2[2], pid;
    if (pipe(pipeFds1) == -1 || pipe(pipeFds2) == -1) {
        log_->error("Problem in creating pipe");
        throw std::runtime_error("Problem in creating pipe");
    }

    pid = fork();
    if (pid == 0) {
        std::vector<std::string> tempArgs = {std::string(EXE_FINANCIAL),
                                             std::string(FINANCIAL_NAME)};
        tempArgs.insert(tempArgs.end(), buildingNames.begin(), buildingNames.end());
        char** args = vectorToCharArray(tempArgs);
        setupUnnamedPipes(pipeFds1, pipeFds2);
        execv(EXE_FINANCIAL, args);
        log_->error("Problem in executing financial unit: " + std::string(FINANCIAL_NAME));
        throw std::runtime_error("Problem in executing financial unit: " +
                                 std::string(FINANCIAL_NAME));
    } else if (pid > 0) {
        close(pipeFds1[0]);
        close(pipeFds2[1]);
        financialUnit_ = new ChildUnit(FINANCIAL_NAME, pipeFds1[1], pipeFds2[0], pid);
    } else {
        log_->error("Problem in forking financial unit");
        throw std::runtime_error("Problem in forking financial unit");
    }
}

void Company::start() {
    while (true) {
        printPrompt();
        std::string input;
        std::getline(std::cin, input);
        std::vector<std::string> args;
        std::string cmd = decode(input, args);
        try {
            handleCmd(cmd, args);
        } catch (const std::exception& e) {
            log_->error("Error occurred while executing command: " + cmd + " with args " +
                        vectorToString(args) + " - " + std::string(e.what()));
        }
    }
}

void Company::printPrompt() {
    std::cout << "-----------------------------------------------------\n"
              << GREEN << ">> " << RESET;
}

void Company::handleCmd(std::string& cmd, const std::vector<std::string>& args) {
    if (cmd == MSG_HELP)
        showHelp();
    else if (cmd == MSG_REPORT)
        reportHandler();
    else if (cmd == MSG_BUILDING)
        printBuildings();
    else if (cmd == MSG_CLOSE)
        closeProcess(false);
    else
        log_->error("unknown command " + cmd + " with args " + vectorToString(args));
}

void Company::closeProcess(bool isError) {
    for (long unsigned int i = 0; i < buildings_.size(); i++) buildings_[i]->sendMessage(MSG_CLOSE);
    financialUnit_->sendMessage(MSG_CLOSE);
}

void Company::printBuildings() {
    std::cout << "***************************************\n";
    std::cout << "Buildings:\n";
    for (long unsigned int i = 0; i < buildings_.size(); i++)
        std::cout << "\t" << BLUE << i << ". " << RESET << GREEN << buildings_[i]->getName()
                  << RESET << "\n";
    std::cout << "***************************************\n";
}

void Company::showHelp() {
    std::cout << GREEN << "\nYou can use the following commands:\n" << RESET;
    std::cout << RED << "1. report:\n" << RESET;
    std::cout << "\t- Usage: " << YELLOW << "report\n";
    std::cout << "\t- Description: " << RESET
              << "Generates a report based on the specified type for a specific building.\n";
    std::cout << "\t- Available report types:\n";
    std::cout << "\t\t- mean: " << CYAN
              << "Calculates the mean value of the specified resource for the given month.\n"
              << RESET;
    std::cout << "\t\t- total: " << CYAN
              << "Calculates the total value of the specified resource for the given month.\n"
              << RESET;
    std::cout << "\t\t- peak: " << CYAN
              << "Finds the peak value of the specified resource for the given month.\n"
              << RESET;
    std::cout << "\t\t- difference: " << CYAN
              << "Calculates the difference between the peak and the mean value of the specified "
                 "resource for the given month.\n"
              << RESET;
    std::cout << "\t\t- bill: " << CYAN
              << "Calculates the bill for the specified resource for the given month.\n"
              << RESET;
    std::cout << "\n";
    std::cout << RED << "2. close:\n" << RESET;
    std::cout << "\t- Usage: " << YELLOW << "close\n";
    std::cout << "\t- Description: " << RESET
              << "Closes the company process and all associated buildings.\n";
    std::cout << "\n";
    std::cout << RED << "3. help:\n" << RESET;
    std::cout << "\t- Usage: " << YELLOW << "help\n";
    std::cout << "\t- Description: " << RESET << "Displays this help file.\n";
}

void Company::reportHandler() {
    std::string type = prompt("Enter report type(mean, total, peak, difference, bill): ");
    std::string name = prompt("Enter building name: ");
    int index = finBuilding(name);
    if (index == -1) {
        log_->error("Building " + std::to_string(index) + "' not found");
        return;
    }
    std::string resource = prompt("Enter resource name(Water, Gas, Electricity): ");
    std::string month = prompt("Enter month number: ");
    if (type == MSG_REPORT_FOR_MEAN) {
        log_->info("Sending mean report request to building " + name);
        meanReport(resource, month, index);
        log_->info("Received mean report response from building " + name);
    } else if (type == MSG_REPORT_FOR_TOTAL) {
        log_->info("Sending total report request to building " + name);
        totalReport(resource, month, index);
        log_->info("Received total report response from building " + name);
    } else if (type == MSG_REPORT_FOR_PEAK) {
        log_->info("Sending peak report request to building " + name);
        maxReport(resource, month, index);
        log_->info("Received peak report response from building " + name);
    } else if (type == MSG_REPORT_FOR_DIFFERENCE) {
        log_->info("Sending difference report request to building " + name);
        diffReport(resource, month, index);
        log_->info("Received difference report response from building " + name);
    } else if (type == MSG_REPORT_BILL) {
        log_->info("Sending bill report request to building " + name);
        billReport(resource, month, index);
        log_->info("Received bill report response from building " + name);
    } else {
        log_->error("Invalid report type: " + type);
    }
}

void Company::meanReport(const std::string& resource, const std::string& month, int index) {
    std::string buildingName = buildings_[index]->getName();

    buildings_[index]->sendMessage(MSG_REPORT_FOR_MEAN, {resource, month});
    std::vector<std::string> resArgs;
    buildings_[index]->receiveMessage(resArgs);

    std::string meanReportStr = resArgs[0];

    std::string reportMessage = "Mean report for " + resource + " in building " + buildingName +
                                " in month " + month + " is: " + meanReportStr;

    std::cout << reportMessage << "\n";
}

void Company::totalReport(const std::string& resource, const std::string& month, int index) {
    std::string buildingName = buildings_[index]->getName();

    buildings_[index]->sendMessage(MSG_REPORT_FOR_TOTAL, {resource, month});
    std::vector<std::string> resArgs;
    buildings_[index]->receiveMessage(resArgs);

    std::string totalReportStr = resArgs[0];

    std::string reportMessage = "Total report for " + resource + " in building " + buildingName +
                                " in month " + month + " is: " + totalReportStr;

    std::cout << reportMessage << "\n";
}

void Company::maxReport(const std::string& resource, const std::string& month, int index) {
    std::string buildingName = buildings_[index]->getName();

    buildings_[index]->sendMessage(MSG_REPORT_FOR_PEAK, {resource, month});
    std::vector<std::string> resArgs;
    buildings_[index]->receiveMessage(resArgs);

    std::string maxHoursStr = "";
    for (const auto& hour : resArgs) {
        maxHoursStr += (hour + " ");
    }

    std::string reportMessage = "Max hours usage report for " + resource + " in building " +
                                buildingName + " in month " + month + " is/are: " + maxHoursStr;

    std::cout << reportMessage << "\n";
}

void Company::diffReport(const std::string& resource, const std::string& month, int index) {
    std::string buildingName = buildings_[index]->getName();

    buildings_[index]->sendMessage(MSG_REPORT_FOR_DIFFERENCE, {resource, month});
    std::vector<std::string> resArgs;
    buildings_[index]->receiveMessage(resArgs);

    std::string reportMessage = "Difference report for " + resource + " in building " +
                                buildingName + " in month " + month + " is: " + resArgs[0];

    std::cout << reportMessage << "\n";
}

void Company::billReport(const std::string& resource, const std::string& month, int index) {
    std::string buildingName = buildings_[index]->getName();
    std::string financialeName = financialUnit_->getName();

    std::vector<std::string> resArgs;
    buildings_[index]->sendMessage(MSG_REPORT_BILL, {resource, month});

    std::vector<std::string> financialArgs = {buildingName};
    financialArgs.push_back(resource);
    financialArgs.push_back(month);
    financialUnit_->sendMessage(MSG_REPORT_BILL, financialArgs);

    buildings_[index]->receiveMessage(resArgs);

    std::string reportMessage = "Bill report for " + resource + " in building " + buildingName +
                                " in month " + month + " is: " + resArgs[0];

    std::cout << reportMessage << "\n";
}

int Company::finBuilding(const std::string& name) {
    auto it = std::find_if(buildings_.begin(), buildings_.end(),
                           [&](const auto& building) { return building->getName() == name; });

    if (it != buildings_.end()) {
        return std::distance(buildings_.begin(), it);
    }

    return -1;
}
