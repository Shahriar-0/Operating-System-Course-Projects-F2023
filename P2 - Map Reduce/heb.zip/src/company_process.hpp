#ifndef COMPANY_PROCESS_HPP_INCLUDE
#define COMPANY_PROCESS_HPP_INCLUDE

#include "communication.hpp"
#include "console_logger.hpp"
#include "consts.hpp"
#include "file_console_logger.hpp"
#include "file_logger.hpp"
#include "logger.hpp"
#include "utils.hpp"

class Company {
public:
    Company(const char* buildingsPath, Logger* log);
    void start();

private:
    Logger* log_;
    std::vector<CommunicationUnit*> buildings_;
    CommunicationUnit* financialUnit_;

    std::vector<std::string> getBuildings(const char* path);
    void printPrompt();
    void createBuildings(const std::vector<std::string>& names, const char* buildingsPath);
    void createFinancialUnit(const std::vector<std::string>& buildingNames);
    void handleCmd(std::string& cmd, const std::vector<std::string>& args);
    void closeProcess(bool isError);
    void showHelp();
    void reportHandler();
    int finBuilding(const std::string& name);
    void meanReport(const std::string& resource, const std::string& month, int index);
    void totalReport(const std::string& resource, const std::string& month, int index);
    void maxReport(const std::string& resource, const std::string& month, int index);
    void diffReport(const std::string& resource, const std::string& month, int index);
    void billReport(const std::string& resource, const std::string& month, int index);
    void printBuildings();
};

#endif
