#include "communication.hpp"

CommunicationUnit::CommunicationUnit(const std::string& name, int id) {
    id_ = id;
    name_ = name;
}

ChildUnit::ChildUnit(const std::string& name, int writefd, int readfd, int id)
    : CommunicationUnit(name, id) {
    writefd_ = writefd;
    readfd_ = readfd;
}

void ChildUnit::sendMessage(const std::string& cmd) {
    write(writefd_, cmd.c_str() + '\0', cmd.size() + 1);
}

void ChildUnit::sendMessage(const std::string& cmd, const std::vector<std::string>& args) {
    std::string msg = encode(cmd, args);
    write(writefd_, msg.c_str() + '\0', msg.size() + 1);
}

std::string ChildUnit::receiveMessage() {
    std::vector<std::string> temp;
    return receiveMessage(temp);
}

std::string ChildUnit::receiveMessage(std::vector<std::string>& args) {
    char buf[BUFSIZE];
    read(readfd_, buf, BUFSIZE);
    std::string cmd = decode(std::string(buf), args);
    return cmd;
}

CoworkerUnit::CoworkerUnit(const std::string& name, int id) : CommunicationUnit(name, id) {
    fifoPath_ = FIFO_PATH + name;
    mkfifo(fifoPath_.c_str(), 0666);
}

void CoworkerUnit::sendMessage(const std::string& cmd) {
    int fd = open(fifoPath_.c_str(), O_WRONLY);
    write(fd, cmd.c_str() + '\0', cmd.size() + 1);
    close(fd);
}

void CoworkerUnit::sendMessage(const std::string& cmd, const std::vector<std::string>& args) {
    std::string msg = encode(cmd, args);
    int fd = open(fifoPath_.c_str(), O_WRONLY);
    write(fd, msg.c_str() + '\0', msg.size() + 1);
    close(fd);
}

std::string CoworkerUnit::receiveMessage() {
    std::vector<std::string> temp;
    return receiveMessage(temp);
}

std::string CoworkerUnit::receiveMessage(std::vector<std::string>& args) {
    int fd = open(fifoPath_.c_str(), O_RDONLY);
    char buf[BUFSIZE];
    read(fd, buf, BUFSIZE);
    close(fd);
    std::string cmd = decode(buf, args);
    return cmd;
}

std::string CommunicationUnit::getName() { return name_; }
