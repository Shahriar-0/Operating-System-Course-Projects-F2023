#include "financial_process.hpp"

Financial::Financial(Logger* log, const std::string& name,
                     const std::vector<std::string>& buildingNames) {
    log_ = log;
    name_ = name;
    log_->info("start to work");
    dto_ = new BillConfig(billCSVPath);
    setupBuildingConnections(buildingNames);
}

void Financial::setupBuildingConnections(const std::vector<std::string>& buildingNames) {
    for (long unsigned int i = 0; i < buildingNames.size(); i++) {
        log_->info("connecting to " + buildingNames[i]);
        buildings_.push_back(new CoworkerUnit(buildingNames[i], DEFAULT_ID));
    }
}

void Financial::start() {
    while (true) {
        std::vector<std::string> args;
        std::string cmd = readfd(STDIN_FILENO, args);
        handleCmd(cmd, args);
    }
}

void Financial::handleCmd(const std::string& cmd, const std::vector<std::string>& args) {
    if (cmd == MSG_CLOSE)
        closeProcess(false);
    else if (cmd == MSG_REPORT_BILL)
        billReport(args);
    else
        log_->error("unknown command");
}

void Financial::billReport(const std::vector<std::string>& args) {
    std::string buildingName = args[0];
    std::string resource = args[1];
    std::string monthStr = args[2];
    int buildingIndex = finBuilding(buildingName);
    std::vector<int> params = dto_->getParam(stoi(monthStr));
    int finalParam;
    if (resource == WATER)
        finalParam = params[0];
    else if (resource == GAS)
        finalParam = params[1];
    else if (resource == ELECTRICITY)
        finalParam = params[2];
    else
        throw new std::runtime_error("unknown resource");

    log_->info("send pararesource to building " + buildingName);
    buildings_[buildingIndex]->sendMessage(MSG_REPORT_DATA, {std::to_string(finalParam)});
}

int Financial::finBuilding(const std::string& name) {
    for (long unsigned int i = 0; i < buildings_.size(); i++) {
        if (name == buildings_[i]->getName()) return i;
    }
    log_->error("building not found");
    return -1;
}

void Financial::closeProcess(bool isError) { throw new std::runtime_error("process closed"); }
