#include "resource_process.hpp"

Resource::Resource(Logger* log, std::string name, std::string path) {
    log_ = log;
    name_ = name;
    CSVPath_ = path + "/" + name + ".csv";
    log_->info("start to work");
    dto_ = new ResourceUsage(CSVPath_);
}

void Resource::start() {
    while (true) {
        std::vector<std::string> args;
        std::string cmd = readfd(STDIN_FILENO, args);
        handleCmd(cmd, args);
    }
}

void Resource::handleCmd(const std::string& cmd, const std::vector<std::string>& args) {
    if (cmd == MSG_CLOSE)
        closeProcess(false);
    else if (cmd == MSG_REPORT_FOR_MEAN)
        meanReport(args);
    else if (cmd == MSG_REPORT_FOR_TOTAL)
        totalReport(args);
    else if (cmd == MSG_REPORT_FOR_PEAK)
        maxReport(args);
    else if (cmd == MSG_REPORT_FOR_DIFFERENCE)
        diffReport(args);
    else if (cmd == MSG_REPORT_BILL)
        billReport(args);
    else
        log_->error("unknown command");
}

void Resource::closeProcess(bool isError) { throw new std::runtime_error("process closed"); }

void Resource::meanReport(const std::vector<std::string>& args) {
    int month = stoi(args[0]);
    int res = dto_->mean(month);
    writefd(STDOUT_FILENO, MSG_RESPONSE, {std::to_string(res)});
}

void Resource::totalReport(const std::vector<std::string>& args) {
    int month = stoi(args[0]);
    int res = dto_->mean(month) * 30;
    writefd(STDOUT_FILENO, MSG_RESPONSE, {std::to_string(res)});
}

void Resource::maxReport(const std::vector<std::string>& args) {
    int month = stoi(args[0]);
    std::vector<int> tempRes = dto_->maxUsage(month);
    std::vector<std::string> res;

    for (long unsigned int i = 0; i < tempRes.size(); i++)
        res.push_back(std::to_string(tempRes[i]));

    writefd(STDOUT_FILENO, MSG_RESPONSE, res);
}

void Resource::diffReport(const std::vector<std::string>& args) {
    int month = stoi(args[0]);
    int res = dto_->difference(month);
    writefd(STDOUT_FILENO, MSG_RESPONSE, {std::to_string(res)});
}

void Resource::billReport(const std::vector<std::string>& args) {
    int month = stoi(args[0]);
    std::string resourceType = args[1];
    int param = stoi(args[2]);
    int res;

    if (resourceType == WATER)
        res = dto_->water(month, param);
    else if (resourceType == GAS)
        res = dto_->gas(month, param);
    else if (resourceType == ELECTRICITY)
        res = dto_->electricity(month, param);
    else {
        log_->error("unknown resource type");
    }
    writefd(STDOUT_FILENO, MSG_RESPONSE, {std::to_string(res)});
}
